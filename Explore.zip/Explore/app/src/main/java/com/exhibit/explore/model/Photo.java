package com.exhibit.explore.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class Photo implements Parcelable {
    public static final Creator<Photo> CREATOR = new Creator<Photo>() {
        public Photo createFromParcel(Parcel source) {
            return new Photo(source);
        }

        public Photo[] newArray(int size) {
            return new Photo[size];
        }
    };

    @SerializedName("service_version")
    public String title;

    public String explanation;
    public String hdurl;
    public String copyright;
    @SerializedName("media_type")
    public String mediatype;
    public String url;

    public Photo() {
    }

    protected Photo(Parcel in) {
        this.title = in.readString();
        this.url = in.readString();
        this.explanation = in.readString();
        this.hdurl = in.readString();
        this.copyright = in.readString();
        this.mediatype = in.readString();
    }

    public boolean hasExplanation() {
        return explanation != null && !explanation.isEmpty();
    }

    public boolean hasCopyRight() {
        return copyright != null && !copyright.isEmpty();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.url);
        dest.writeString(this.explanation);
        dest.writeString(this.hdurl);
        dest.writeString(this.copyright);
        dest.writeString(this.mediatype);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Photo user = (Photo) o;
        if (title != null ? !title.equals(user.title) : user.title != null) return false;
        if (url != null ? !url.equals(user.url) : user.url != null) return false;
        if (explanation != null ? !explanation.equals(user.explanation) : user.explanation != null)
            return false;
        if (hdurl != null ? !hdurl.equals(user.hdurl) : user.hdurl != null) return false;
        if (copyright != null ? !copyright.equals(user.copyright) : user.copyright != null)
            return false;
        return !(mediatype != null ? !mediatype.equals(user.mediatype) : user.mediatype != null);

    }

    @Override
    public int hashCode() {
        int result = (title != null ? title.hashCode() : 0);
        result = 31 * result + (url != null ? url.hashCode() : 0);
        result = 31 * result + (explanation != null ? explanation.hashCode() : 0);
        result = 31 * result + (hdurl != null ? hdurl.hashCode() : 0);
        result = 31 * result + (copyright != null ? copyright.hashCode() : 0);
        result = 31 * result + (mediatype != null ? mediatype.hashCode() : 0);
        return result;
    }
}
