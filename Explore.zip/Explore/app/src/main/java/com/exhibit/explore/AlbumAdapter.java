package com.exhibit.explore;

import android.databinding.DataBindingUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.exhibit.explore.databinding.ItemBinding;
import com.exhibit.explore.model.Album;
import com.exhibit.explore.viewmodel.ItemAlbumViewModel;

import java.util.Collections;
import java.util.List;


public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.AlbumViewHolder> {

    private List<Album> albumList;

    public AlbumAdapter() {
        this.albumList = Collections.emptyList();
    }

    public AlbumAdapter(List<Album> albumList) {
        this.albumList = albumList;
    }

    public void setAlbumList(List<Album> albumList) {
        this.albumList = albumList;
    }

    @Override
    public AlbumViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ItemBinding binding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.item,
                parent,
                false);
        return new AlbumViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(AlbumViewHolder holder, int position) {
        holder.bindPhotoAlbum(albumList.get(position));
    }

    @Override
    public int getItemCount() {
        return albumList.size();
    }

    public static class AlbumViewHolder extends RecyclerView.ViewHolder {
        final ItemBinding binding;

        public AlbumViewHolder(ItemBinding binding) {
            super(binding.cardView);
            this.binding = binding;
        }

        void bindPhotoAlbum(Album album) {
            if (binding.getViewModel() == null) {
                binding.setViewModel(new ItemAlbumViewModel(itemView.getContext(), album));
            } else {
                binding.getViewModel().setAlbum(album);
            }
        }
    }
}
