package com.exhibit.explore.view;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.exhibit.explore.AlbumAdapter;
import com.exhibit.explore.R;
import com.exhibit.explore.databinding.MainActivityBinding;
import com.exhibit.explore.model.Album;
import com.exhibit.explore.viewmodel.MainViewModel;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements MainViewModel.DataListener {

    private MainActivityBinding binding;
    private MainViewModel mainViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.main_activity);
        mainViewModel = new MainViewModel(this, this);
        binding.setViewModel(mainViewModel);
        setupRecyclerView(binding.recyclerView);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mainViewModel.destroy();
    }

    @Override
    public void onDataChanged(Album album) {
        AlbumAdapter adapter =
                (AlbumAdapter) binding.recyclerView.getAdapter();

        List<Album> albumList = new ArrayList<>();

        if (album != null)
            albumList.add(album);

        adapter.setAlbumList(albumList);
        adapter.notifyDataSetChanged();
    }

    private void setupRecyclerView(RecyclerView recyclerView) {
        AlbumAdapter adapter = new AlbumAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


}
