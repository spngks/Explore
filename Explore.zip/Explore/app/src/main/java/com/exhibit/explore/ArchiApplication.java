package com.exhibit.explore;

import android.app.Application;
import android.content.Context;

import com.exhibit.explore.model.NasaService;

import rx.Scheduler;
import rx.schedulers.Schedulers;

public class ArchiApplication extends Application {

    private NasaService nasaService;
    private Scheduler defaultSubscribeScheduler;

    public static ArchiApplication get(Context context) {
        return (ArchiApplication) context.getApplicationContext();
    }

    public NasaService getNasaService() {
        if (nasaService == null) {
            nasaService = NasaService.Factory.create();
        }
        return nasaService;
    }

    //For setting mocks during testing
    public void setNasaService(NasaService nasaService) {
        this.nasaService = nasaService;
    }

    public Scheduler defaultSubscribeScheduler() {
        if (defaultSubscribeScheduler == null) {
            defaultSubscribeScheduler = Schedulers.io();
        }
        return defaultSubscribeScheduler;
    }

    //User to change scheduler from tests
    public void setDefaultSubscribeScheduler(Scheduler scheduler) {
        this.defaultSubscribeScheduler = scheduler;
    }
}
