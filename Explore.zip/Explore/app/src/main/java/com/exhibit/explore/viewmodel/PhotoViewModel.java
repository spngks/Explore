package com.exhibit.explore.viewmodel;

import android.content.Context;
import android.databinding.BindingAdapter;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.view.View;
import android.widget.ImageView;

import com.exhibit.explore.R;
import com.exhibit.explore.model.Album;
import com.squareup.picasso.Picasso;

import rx.Subscription;


/**
 * ViewModel for the DetailActivity
 */
public class PhotoViewModel implements ViewModel {

    private static final String TAG = "PhotoViewModel";
    public ObservableInt photoUrlVisibility;
    public ObservableInt photoLayoutVisibility;
    private Album album;
    private Context context;
    private Subscription subscription;

    public PhotoViewModel(Context context, final Album album) {
        this.album = album;
        this.context = context;
        this.photoLayoutVisibility = new ObservableInt(View.VISIBLE);
        this.photoUrlVisibility = new ObservableInt(View.VISIBLE);


    }

    @BindingAdapter({"url"})
    public static void loadImage(ImageView view, String url) {
        Picasso.with(view.getContext())
                .load(url)
                .placeholder(R.drawable.placeholder)
                .into(view);
    }

    public String getTitle() {
        return album.title;
    }

    public String getExplanation() {
        return album.explanation;
    }

    public String getHdurl() {
        return album.hdurl;
    }

    public String getUrl() {
        return album.url;
    }

    public int getPhotoUrlVisibility() {
        return (album.url!=null && !album.url.isEmpty())  ? View.VISIBLE : View.GONE;
    }

    public int getPhotoLayoutVisibility() {
        // TODO add all checks
        return (album.url!=null && !album.url.isEmpty()) ? View.VISIBLE : View.GONE;
    }

    @Override
    public void destroy() {
        this.context = null;
        if (subscription != null && !subscription.isUnsubscribed()) subscription.unsubscribe();
    }


}
