package com.exhibit.explore.viewmodel;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.BindingAdapter;
import android.view.View;
import android.widget.ImageView;

import com.exhibit.explore.R;
import com.exhibit.explore.model.Album;
import com.exhibit.explore.view.DetailsActivity;
import com.squareup.picasso.Picasso;

/**
 * View model for each item in the  RecyclerView
 */
public class ItemAlbumViewModel extends BaseObservable implements ViewModel {

    private Album album;
    private Context context;

    public ItemAlbumViewModel(Context context, Album album) {
        this.album = album;
        this.context = context;
    }

    public String getUrl() {
        return album.url;
    }

    public String getTitle() {
        return album.title;
    }

    public String getExplanation() {
        return album.explanation;
    }

    public void onItemClick(View view) {
        context.startActivity(DetailsActivity.newIntent(context, album));
    }

    @BindingAdapter({"url"})
    public static void loadImage(ImageView view, String url) {
        Picasso.with(view.getContext())
                .load(url)
                .placeholder(R.drawable.placeholder)
                .into(view);
    }

    // Allows recycling ItemViewModels within the recyclerview adapter
    public void setAlbum(Album album) {
        this.album = album;
        notifyChange();
    }

    @Override
    public void destroy() {
        //In this case destroy doesn't need to do anything because there is not async calls
    }

}
