package com.exhibit.explore.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Album implements Parcelable {
    public static final Creator<Album> CREATOR = new Creator<Album>() {
        public Album createFromParcel(Parcel source) {
            return new Album(source);
        }

        public Album[] newArray(int size) {
            return new Album[size];
        }
    };

    public String title;
    public String explanation;
    public String url;
    public String hdurl;
    public Photo photo;


    public Album() {
    }

    protected Album(Parcel in) {
        this.title = in.readString();
        this.explanation = in.readString();
        this.url = in.readString();
        this.hdurl = in.readString();
        this.photo = in.readParcelable(Photo.class.getClassLoader());
    }

    public boolean hasHomepage() {
        return hdurl != null && !hdurl.isEmpty();
    }

    public boolean hasLanguage() {
        return url != null && !url.isEmpty();
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.explanation);
        dest.writeString(this.url);
        dest.writeString(this.hdurl);
        dest.writeParcelable(this.photo, 0);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Album that = (Album) o;

        if (title != null ? !title.equals(that.title) : that.title != null) return false;
        if (explanation != null ? !explanation.equals(that.explanation) : that.explanation != null)
            return false;
        if (url != null ? !url.equals(that.url) : that.url != null)
            return false;
        if (hdurl != null ? !hdurl.equals(that.hdurl) : that.hdurl != null)
            return false;
        return !(photo != null ? !photo.equals(that.photo) : that.photo != null);

    }

    @Override
    public int hashCode() {
        int result = (title != null ? title.hashCode() : 0);
        result = 31 * result + (explanation != null ? explanation.hashCode() : 0);
        result = 31 * result + (url != null ? url.hashCode() : 0);
        result = 31 * result + (hdurl != null ? hdurl.hashCode() : 0);
        result = 31 * result + (photo != null ? photo.hashCode() : 0);
        return result;
    }
}
