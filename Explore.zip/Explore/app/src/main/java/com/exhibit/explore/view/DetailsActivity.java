package com.exhibit.explore.view;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;

import com.exhibit.explore.R;
import com.exhibit.explore.databinding.DetailActivityBinding;
import com.exhibit.explore.model.Album;
import com.exhibit.explore.viewmodel.PhotoViewModel;


public class DetailsActivity extends AppCompatActivity {

    private static final String EXTRA_PHOTOS = "EXTRA_PHOTOS";

    private DetailActivityBinding binding;
    private PhotoViewModel photoViewModel;

    public static Intent newIntent(Context context, Album album) {
        Intent intent = new Intent(context, DetailsActivity.class);
        intent.putExtra(EXTRA_PHOTOS, album);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.detail_activity);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        Album album = getIntent().getParcelableExtra(EXTRA_PHOTOS);
        photoViewModel = new PhotoViewModel(this, album);
        binding.setViewModel(photoViewModel);
        setTitle(album.title);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        photoViewModel.destroy();
    }
}
