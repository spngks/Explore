package com.exhibit.explore.viewmodel;

/**
 * Interface that every ViewModel must implement
 */
public interface ViewModel {

    void destroy();
}
