package com.exhibit.explore.viewmodel;

import android.content.Context;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.util.Log;
import android.view.View;

import com.exhibit.explore.ArchiApplication;
import com.exhibit.explore.R;
import com.exhibit.explore.model.Album;
import com.exhibit.explore.model.NasaService;

import retrofit2.adapter.rxjava.HttpException;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

/**
 * View model for the MainActivity
 */
public class MainViewModel implements ViewModel {

    private static final String TAG = "MainViewModel";

    public ObservableInt progressVisibility;
    public ObservableInt recyclerViewVisibility;
    public ObservableInt infoMessageVisibility;
    public ObservableField<String> infoMessage;

    private Context context;
    private Subscription subscription;
    private Album album;
    private DataListener dataListener;


    public MainViewModel(Context context, DataListener dataListener) {
        this.context = context;
        this.dataListener = dataListener;
        infoMessageVisibility = new ObservableInt(View.VISIBLE);
        progressVisibility = new ObservableInt(View.INVISIBLE);
        recyclerViewVisibility = new ObservableInt(View.INVISIBLE);
        infoMessage = new ObservableField<>(context.getString(R.string.default_info_message));

        loadPublicNASAPhotos();
    }

    private static boolean isHttp404(Throwable error) {
        return error instanceof HttpException && ((HttpException) error).code() == 404;
    }

    public void setDataListener(DataListener dataListener) {
        this.dataListener = dataListener;
    }

    @Override
    public void destroy() {
        if (subscription != null && !subscription.isUnsubscribed()) subscription.unsubscribe();
        subscription = null;
        context = null;
        dataListener = null;
    }


    private void loadPublicNASAPhotos() {
        progressVisibility.set(View.VISIBLE);
        recyclerViewVisibility.set(View.INVISIBLE);

        infoMessageVisibility.set(View.GONE);
        if (subscription != null && !subscription.isUnsubscribed()) subscription.unsubscribe();
        ArchiApplication application = ArchiApplication.get(context);
        NasaService nasaService = application.getNasaService();
        subscription = nasaService.publicPhotos()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(application.defaultSubscribeScheduler())
                .subscribe(new Subscriber<Album>() {
                    @Override
                    public void onCompleted() {
                        if (dataListener != null) dataListener.onDataChanged(album);
                        progressVisibility.set(View.INVISIBLE);
                        if (album != null) {
                            recyclerViewVisibility.set(View.VISIBLE);
                        } else {
                            infoMessage.set(context.getString(R.string.text_empty_album));
                            infoMessageVisibility.set(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onError(Throwable error) {
                        Log.e(TAG, "Error loading ", error);
                        progressVisibility.set(View.INVISIBLE);
                        if (isHttp404(error)) {
                            infoMessage.set(context.getString(R.string.error_api_not_found));
                        } else {
                            infoMessage.set(context.getString(R.string.error_loading_photos));
                        }
                        infoMessageVisibility.set(View.VISIBLE);
                    }


                    @Override
                    public void onNext(Album album) {
                        Log.i(TAG, " loaded " + album);
                        MainViewModel.this.album = album;
                    }
                });
    }

    public interface DataListener {
        void onDataChanged(Album albumList);
    }
}
